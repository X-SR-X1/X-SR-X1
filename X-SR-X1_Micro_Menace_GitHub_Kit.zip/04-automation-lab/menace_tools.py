"""Micro Menace automation tools: safe defaults, standard library only."""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
import shutil

CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp"},
    "Documents": {".pdf", ".docx", ".doc", ".txt", ".md", ".csv", ".xlsx", ".xls", ".pptx"},
    "Archives": {".zip", ".7z", ".tar", ".gz", ".rar"},
    "Videos": {".mp4", ".mov", ".mkv", ".avi", ".webm"},
    "Audio": {".mp3", ".wav", ".m4a", ".flac", ".ogg"},
}


def category(path: Path) -> str:
    """Return a human-friendly folder based on file extension."""
    for name, extensions in CATEGORIES.items():
        if path.suffix.lower() in extensions:
            return name
    return "Other"


def safe_destination(folder: Path, filename: str) -> Path:
    """Suggest a non-overwriting destination (also safe from existing directories)."""
    desired = folder / filename
    if not desired.exists():
        return desired
    file = Path(filename)
    counter = 1
    while True:
        candidate = folder / f"{file.stem} ({counter}){file.suffix}"
        if not candidate.exists():
            return candidate
        counter += 1


def organize(folder: Path, *, apply: bool = False) -> list[tuple[Path, Path]]:
    if not folder.is_dir():
        raise NotADirectoryError(folder)
    moves = []
    for source in sorted(folder.iterdir()):
        if not source.is_file() or source.name.startswith("."):
            continue
        target_dir = folder / category(source)
        target = safe_destination(target_dir, source.name)
        moves.append((source, target))
        if apply:
            target_dir.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(target))
    return moves


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def duplicates(folder: Path) -> dict[str, list[Path]]:
    if not folder.is_dir():
        raise NotADirectoryError(folder)
    by_size: dict[int, list[Path]] = {}
    for p in folder.rglob("*"):
        if p.is_file() and not p.is_symlink():
            try:
                by_size.setdefault(p.stat().st_size, []).append(p)
            except (OSError, PermissionError):
                continue
    matches: dict[str, list[Path]] = {}
    for same_size in by_size.values():
        if len(same_size) < 2:
            continue
        for path in same_size:
            try:
                matches.setdefault(sha256(path), []).append(path)
            except (OSError, PermissionError):
                continue
    return {digest: paths for digest, paths in matches.items() if len(paths) > 1}


def main() -> None:
    parser = argparse.ArgumentParser(description="Micro Menace safe local file tools.")
    sub = parser.add_subparsers(dest="action", required=True)
    p_organize = sub.add_parser("organize", help="Preview or apply simple file organization")
    p_organize.add_argument("folder", type=Path)
    p_organize.add_argument("--apply", action="store_true", help="Actually move files (off by default)")
    p_duplicates = sub.add_parser("duplicates", help="Find duplicates without deleting anything")
    p_duplicates.add_argument("folder", type=Path)
    args = parser.parse_args()
    try:
        folder = args.folder.expanduser().resolve()
        if args.action == "organize":
            moves = organize(folder, apply=args.apply)
            print("APPLIED" if args.apply else "DRY RUN — nothing changed")
            for source, target in moves:
                print(f"{source.name}  →  {target.relative_to(folder)}")
            print(f"Files: {len(moves)}")
        elif args.action == "duplicates":
            groups = duplicates(folder)
            for group in groups.values():
                print("\nDuplicate group:")
                for path in group:
                    print(f"  {path}")
            print(f"\nDuplicate groups: {len(groups)}. Nothing deleted.")
    except (OSError, PermissionError) as exc:
        parser.exit(1, f"Error: {exc}\n")


if __name__ == "__main__":
    main()
