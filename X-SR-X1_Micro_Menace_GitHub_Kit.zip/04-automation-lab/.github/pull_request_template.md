## What changed?

## Why?

## Testing done
- [ ] Unit tests pass
- [ ] No personal data, credentials, or secrets included
- [ ] File-changing actions are safe by default
