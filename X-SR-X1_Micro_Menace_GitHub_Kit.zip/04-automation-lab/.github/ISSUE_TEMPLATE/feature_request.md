---
name: Feature request
about: Suggest an improvement
title: "[IDEA] "
labels: enhancement
assignees: ''
---

**What's the idea?**

**Why is it useful?**

**How should it work?**
