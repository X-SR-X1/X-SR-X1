---
name: Bug report
about: Something isn't working as expected
title: "[BUG] "
labels: bug
assignees: ''
---

**What happened?**

**What did you expect?**

**Steps to reproduce:**
1.
2.
3.

**Operating system / Python version:**

**Relevant output (remove personal information first):**
