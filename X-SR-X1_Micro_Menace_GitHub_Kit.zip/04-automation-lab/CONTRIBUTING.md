# Contributing

1. Open an issue describing the problem or feature.
2. Make a small, focused change.
3. Run `python -m unittest discover -s tests -v`.
4. Open a pull request explaining what changed.

Please do not include personal files, passwords, access tokens, or other secrets.
