# 🐍 Automation Lab

A useful, beginner-friendly Python CLI starter project with zero external dependencies.

## What it does
- `organize`: sorts files by category (Images, Documents, Archives, Videos, Audio, Other)
- `duplicates`: detects identical files by SHA-256 *without deleting them*
- `--apply`: explicitly required for changing/moving files. Normal mode is a **dry run**.

## Requirements
Python 3.10 or newer.

## Examples (Windows Terminal / PowerShell)
```powershell
python menace_tools.py organize "C:\Users\YourName\Downloads"
python menace_tools.py organize "C:\Users\YourName\Downloads" --apply
python menace_tools.py duplicates "C:\Users\YourName\Downloads"
```

Do NOT run the `--apply` version until you have reviewed its proposed moves and have a backup of important files.
The organizer only scans files directly in the selected folder (not subdirectories).
`duplicates` scans subdirectories but does not change anything.
`organize` skips hidden files and will never overwrite an existing destination file.

## Run tests
```powershell
python -m unittest discover -s tests -v
```

A GitHub Actions workflow runs tests automatically on every push and pull request.

## Notes
Never run a downloaded program without reading the code first. No admin rights are required.
