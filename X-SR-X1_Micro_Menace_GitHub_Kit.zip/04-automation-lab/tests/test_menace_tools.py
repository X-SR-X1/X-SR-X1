import tempfile
import unittest
from pathlib import Path

from menace_tools import category, duplicates, organize, safe_destination


class MenaceToolsTests(unittest.TestCase):
    def test_category(self):
        self.assertEqual(category(Path("holiday.JPG")), "Images")
        self.assertEqual(category(Path("notes.pdf")), "Documents")
        self.assertEqual(category(Path("file.unknown")), "Other")

    def test_safe_destination_never_overwrites(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "test.txt").write_text("old")
            self.assertEqual(safe_destination(folder, "test.txt").name, "test (1).txt")

    def test_organize_dry_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            source = folder / "photo.jpg"
            source.write_bytes(b"picture")
            proposed = organize(folder)
            self.assertEqual(proposed[0][1], folder / "Images" / "photo.jpg")
            self.assertTrue(source.is_file())
            self.assertFalse((folder / "Images").exists())

    def test_organize_apply(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "example.pdf").write_text("a")
            organize(folder, apply=True)
            self.assertTrue((folder / "Documents" / "example.pdf").is_file())

    def test_duplicate_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "a.txt").write_text("same")
            (folder / "b.txt").write_text("same")
            (folder / "c.txt").write_text("different")
            groups = list(duplicates(folder).values())
            self.assertEqual(len(groups), 1)
            self.assertEqual({p.name for p in groups[0]}, {"a.txt", "b.txt"})


if __name__ == "__main__":
    unittest.main()
