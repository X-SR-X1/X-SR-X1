# 🧰 Dev Toolbox

A free, responsive, browser-only developer toolkit. No registration or server-side processing needed.

**Tools**
- Cryptographically secure password generator (uses `crypto.getRandomValues`)
- JSON prettifier and syntax validator
- URL encode/decode
- Text ↔ Base64 (UTF-8)
- SHA-256 content digest (browser `crypto.subtle`)

Everything runs in your browser. Nothing is uploaded by this site.

## Run
Open `index.html`, or publish with GitHub Pages (**Settings → Pages → Source: GitHub Actions**).

**Note:** Encryption/hashing is not the same as password storage. The hash feature shows a raw SHA-256 content digest; it is **not** a safe password-storage scheme. Do not paste passwords or sensitive data into online sites you do not trust.
