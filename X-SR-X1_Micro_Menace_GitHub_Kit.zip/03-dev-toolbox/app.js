'use strict';
const $ = s => document.querySelector(s);
const status = (id, msg) => { $(id).textContent = msg; };
async function copyValue(value, id) {
  if (!value) { status(id, 'Nothing to copy yet.'); return; }
  try { await navigator.clipboard.writeText(value); status(id, 'Copied.'); }
  catch { status(id, 'Clipboard unavailable. Select the text and copy manually.'); }
}
function secureInt(max) {
  const array = new Uint32Array(1);
  const limit = 0x100000000 - (0x100000000 % max);
  do { crypto.getRandomValues(array); } while (array[0] >= limit);
  return array[0] % max;
}
const passwordChars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
const symbols = '!@#$%^&*()-_=+?';
$('#length').addEventListener('input', () => $('#length-value').textContent = $('#length').value);
$('#generate').addEventListener('click', () => {
  try {
    const chars = passwordChars + ($('#symbols').checked ? symbols : '');
    const length = Number($('#length').value);
    $('#password').value = Array.from({length}, () => chars[secureInt(chars.length)]).join('');
    status('#pw-status', 'Generated locally with crypto.getRandomValues.');
  } catch (e) { status('#pw-status', 'Secure randomness unavailable: ' + e.message); }
});
$('#copy-password').addEventListener('click', () => copyValue($('#password').value, '#pw-status'));
$('#format-json').addEventListener('click', () => {
  try { $('#json-input').value = JSON.stringify(JSON.parse($('#json-input').value), null, 2); status('#json-status', '✓ Valid JSON'); }
  catch (e) { status('#json-status', '✗ ' + e.message); }
});
$('#minify-json').addEventListener('click', () => {
  try { $('#json-input').value = JSON.stringify(JSON.parse($('#json-input').value)); status('#json-status', '✓ Valid JSON · minified'); }
  catch (e) { status('#json-status', '✗ ' + e.message); }
});
const textToBase64 = text => {
  const bytes = new TextEncoder().encode(text);
  let binary = ''; for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
};
const base64ToText = text => {
  const binary = atob(text.trim()); const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
  return new TextDecoder('utf-8', {fatal: true}).decode(bytes);
};
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => {
  const text = $('#convert-input').value;
  try {
    const functions = {
      'url-encode': encodeURIComponent,
      'url-decode': decodeURIComponent,
      'b64-encode': textToBase64,
      'b64-decode': base64ToText
    };
    $('#convert-output').value = functions[button.dataset.mode](text);
    status('#convert-status', '✓ Converted locally.');
  } catch (e) { status('#convert-status', '✗ Invalid input: ' + e.message); }
}));
$('#hash').addEventListener('click', async () => {
  try {
    const bytes = new TextEncoder().encode($('#hash-input').value);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    $('#hash-output').value = [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2,'0')).join('');
    status('#hash-status', '✓ SHA-256 digest ready.');
  } catch (e) { status('#hash-status', 'Hashing unavailable in this browser/context: ' + e.message); }
});
$('#copy-hash').addEventListener('click', () => copyValue($('#hash-output').value, '#hash-status'));
$('#generate').click();
