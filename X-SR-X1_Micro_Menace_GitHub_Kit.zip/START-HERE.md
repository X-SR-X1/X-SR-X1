# 🟣 MICRO MENACE — GitHub launch kit

A complete starter pack, built for **Sam** and the **Dell Micro Menace 3080**.

This pack contains **four separate GitHub repositories** (not one giant repo):

| Folder | GitHub repository name | Purpose |
|---|---|---|
| `01-PROFILE` | **X-SR-X1** | Your custom public GitHub profile |
| `02-micro-menace-command-centre` | **micro-menace-command-centre** | Futuristic, interactive website |
| `03-dev-toolbox` | **dev-toolbox** | Useful browser-based developer tools |
| `04-automation-lab` | **automation-lab** | Real Python automation scripts and tests |

## Easy start: ONE STEP AT A TIME

**Step 1 — Create your account**
Go to https://github.com/signup, create an account and verify your email.
Use a unique password and enable 2-factor authentication. Never share passwords, passkeys, recovery codes or tokens with anyone.

**Step 2 — Choose your username**
A few possible handles: `MicroMenace3080`, `LittleManLabs`, `SamBuildsStuff`, `MenaceModeDev`.
Choose whatever is available. Your GitHub username does **not** have to match your PC name.

**Step 3 — Create the profile repository**
In GitHub: **+ → New repository**. For the repository name, use your **exact GitHub username**.
Select **Public**, then create it. Upload the *contents* of `01-PROFILE` to the root.
Edit `README.md` and replace `X-SR-X1` with your real GitHub username.
Your README should then appear on your profile.

**Step 4 — Publish the command centre**
Create a second **Public** repository called `micro-menace-command-centre`.
Upload the contents of `02-micro-menace-command-centre` to its root.
Open **Settings → Pages → Build and deployment** and choose **GitHub Actions** as the source.
The included workflow publishes automatically when you push to `main` (check the Actions tab).
Expected URL: `https://X-SR-X1.github.io/micro-menace-command-centre/`

**Step 5 — Add the dev toolbox**
Create a Public repository called `dev-toolbox` and upload the contents of `03-dev-toolbox`.
Choose **Settings → Pages → GitHub Actions**; its included workflow publishes the tool.
Expected URL: `https://X-SR-X1.github.io/dev-toolbox/`

**Step 6 — Add your Python automation projects**
Create a repository called `automation-lab` and upload the contents of `04-automation-lab`.
The included GitHub Actions workflow runs unit tests on each push.

**Step 7 — Finish your profile**
In the profile README, replace all placeholders and optionally add links to the two live sites.
Pin your three project repositories from your GitHub profile under **Customize your pins**.
Add a short bio, profile picture and a strong account recovery method.

## Important
- These are **local files**, not repositories already uploaded to GitHub.
- The web projects work by opening `index.html` in your browser and need no paid hosting.
- Browser tools store any local notes/tasks in *that browser only*. No cloud sync.
- The terminal in the command centre is a **simulated learning terminal**. It never runs commands on your PC.
- The Python automation lab defaults to **dry-run**: no files are moved unless explicitly requested.
- Do not upload passwords, private keys, API tokens, private files, or personal information.
- GitHub Pages is public web hosting, not suitable for private data.
