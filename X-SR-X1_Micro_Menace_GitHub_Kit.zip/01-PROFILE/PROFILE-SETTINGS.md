# Profile settings suggestions

**Display name:** Sam | Micro Menace Labs

**Bio (copy/paste):**
Hands-on builder 🛠️ | Python, web experiments & useful automations | Turning odd ideas into working projects ⚡

**Location:** optional — consider leaving it blank for privacy.

**Website:** your GitHub Pages command centre once published, e.g.
https://X-SR-X1.github.io/micro-menace-command-centre/

**Pinned repositories:**
1. micro-menace-command-centre
2. dev-toolbox
3. automation-lab

**Security checklist:**
- 2FA enabled
- Recovery codes stored privately offline
- Public email hidden if desired
- No API keys or passwords committed to projects

None of these settings are applied automatically.
