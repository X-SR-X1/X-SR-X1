<div align="center">

# ⚡ SAM // MICRO MENACE LABS
### Curious mind. Unusual ideas. Actual working code.

**Building tools, breaking down problems, and experimenting with what computers can do.**

`🖥️ Dell Micro Menace 3080` &nbsp; `⚙️ Python` &nbsp; `🌐 Web` &nbsp; `🐧 Linux` &nbsp; `🧪 Learning in public`

---

</div>

### 👋 Hey, I'm Sam

I'm a hands-on maker getting deeper into software, automation, web development, Linux and networking.
I like building things that are useful, slightly ridiculous, and way more interesting than a blank screen.

- 🟣 **Building:** a futuristic Micro Menace command centre
- 🔧 **Experimenting:** little web apps, browser-based utilities and Python automations
- 🧠 **Learning:** Git, GitHub, JavaScript, Python and safe home-lab networking
- 🚀 **Goal:** turn ambitious ideas into working projects

### 🚀 Featured projects

| Project | What it does |
| --- | --- |
| **[Micro Menace Command Centre](https://github.com/X-SR-X1/micro-menace-command-centre)** | Interactive neon dashboard, task tracking, terminal simulator and a secure code experiment sandbox |
| **[Dev Toolbox](https://github.com/X-SR-X1/dev-toolbox)** | Password generator, JSON formatter, text/URL encoders and SHA-256 hash tool |
| **[Automation Lab](https://github.com/X-SR-X1/automation-lab)** | Python file organiser in safe dry-run mode, duplicate file checks and tests |

### 🧰 Tech I'm exploring

![Python](https://img.shields.io/badge/Python-Experimenting-3776AB?logo=python&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-Building-F7DF1E?logo=javascript&logoColor=black)
![HTML](https://img.shields.io/badge/HTML-Web%20projects-E34F26?logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS-Design%20lab-1572B6?logo=css&logoColor=white)
![GitHub](https://img.shields.io/badge/GitHub-Learning-181717?logo=github&logoColor=white)

### 🎯 On my radar

- [x] Build my first interactive web project
- [x] Make a useful developer utility suite
- [x] Set up a testable Python project
- [ ] Publish my first project using GitHub Pages
- [ ] Learn how pull requests work
- [ ] Build a small automation that saves real time

---

<div align="center">

**Less scrolling. More building.** ⚡

*All progress is real. No fake badges, metrics or claims.*

</div>
